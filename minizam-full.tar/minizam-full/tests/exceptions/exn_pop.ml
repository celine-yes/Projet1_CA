let _ =
  (try 12 with _ -> 0) + 28
