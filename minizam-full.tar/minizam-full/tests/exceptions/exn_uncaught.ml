exception E

let _ =
  raise E
