let f x = x - 2

let _ = f 5
