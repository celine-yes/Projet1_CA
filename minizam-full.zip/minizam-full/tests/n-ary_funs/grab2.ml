let f x y = x - y

let f_deux = (fun x -> f x 2)

let _ = f_deux 5
