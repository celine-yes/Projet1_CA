let plus x y z =
  let a = 10 in
  a + x + y + z

let plus_deux = plus 2

let plus_deux_cinq = plus_deux 5

let _ = plus_deux_cinq 4
