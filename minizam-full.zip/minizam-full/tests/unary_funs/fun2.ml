(fun x -> (fun y -> x + y) 2) 3
