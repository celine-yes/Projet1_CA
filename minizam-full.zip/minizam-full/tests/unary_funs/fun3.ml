(fun x -> if x then print_char 'A'  else print_char 'B') true
